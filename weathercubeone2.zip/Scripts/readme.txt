WeatherCubeOne Script Hints

Define the script on the Raspberry Pi using $sudo nano scriptname.sh
This to avoid DOS or MAC character mismatch.

Make the script executable: $sudo chmod 755 scriptname.sh
Test using ./scripname.sh

Start the script at reboot via crontab: $sudo crontab -e
@reboot sudo /home/pi/tinkerforge/mqtt/tinkerforgemqttproxy.sh
@reboot sudo /home/pi/weathercubeone.sh
To checkthe crontab, use $sudo crontab -l

Tinkerforge
When upgrading the MQTT proxy in folder /home/pi/tinkerforge/mqtt ensure to run
  $sudo pip install tinkerforge --upgrade
This ensures the latest libraries are installed which are used by the proxy.

Check in the Domoticz log if MQTT is running.
Updates occur, if one of the TinkerForge Bricklets changed value.
