#!/bin/bash
# Script to show copyright message on weathercubeone
echo "WeatherCubeOne show copyright..."
mosquitto_pub -h localhost -t weathercubeone/copyright -m ""
