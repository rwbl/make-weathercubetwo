#!/bin/bash
# Script to start TinkerForge MQTT proxy
# v20160624 by rwblinn.de
echo "TinkerForge MQTT Proxy starting..."
#TinkerForge Brick MQTT Proxy
cd /home/pi/tinkerforge/mqtt 
#
#python brick-mqtt-proxy.py&
#Default interval is 3 seconds, change to 1 min by setting to 60
python brick-mqtt-proxy.py --update-interval 60 &
printf "TinkerForge Brick MQTT Proxy started"
