cd /home/pi/weathercubeone
sudo /usr/bin/java -jar weathercubeone.jar&

